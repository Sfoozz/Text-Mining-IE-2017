import re
class BigramModel:
    """
    Takes a corpus as a list of tokenised sentences as input (each sentence
    must be a list of words). Analyses this to generate a dictionary containing
    all bigrams in the corpus.
    Methods p_raw and p_smooth compute bigram probability.
    Method successors takes a word as input and specifies which words follow it
    in the corpus, and what their probability is.
    Method perplexity takes tokenised sentence as input and calculates its
    perplexity for the given corpus.

    By Davy Baardink, Luka van der Plas & Tessa Vermeir
    """
    def __init__(self, list):
        """
        Takes the argument list and removes all punctuation, converts it to
        lower case and adds sentence boundary tokens.
        Creates a set of unigrams (unigrams) and a bigram dictionary
        (bigramscount) which lists for each word n in the text all the words
        that followed n and the frequency of this bigram.
        Also computers the inter value (typescount) of the number of word
        types in the corpus.
        """
        self.nicelist = []
        for sentence in list:
            sentlist = self._makenice(sentence)
            self.nicelist.append(sentlist)
        unigramlist = []
        for sentence in self.nicelist:
            for word in sentence:
                unigramlist.append(word)
        self.unigrams = set(unigramlist)
        self.bigramscount = {}              #dictionary used to store all bigrams and their counts
        self.unigramcount = {}              #dictionary storing all unigrams with their frequency
        for word in self.unigrams:
            self.bigramscount[word] = {}
            self.unigramcount[word] = 0
        for sentence in self.nicelist:
            for x in range(0, len(sentence)-1):
                word1 = sentence[x]
                word2 = sentence[x+1]
                if word2 in self.bigramscount[word1]:
                    self.bigramscount[word1][word2] += 1
                else:
                    self.bigramscount[word1][word2] = 1
                self.unigramcount[word1] +=1
            self.unigramcount[sentence[-1]] += 1
        self.typescount = len(self.unigrams)

    def _makenice(self, sentence):
        """
        Takes a tokenised sentence (a list of words) as input and returns it in
        a form suitable for anylysis.
        Removes word-final an word-initial punctuation and converts all words
        to lowercase. Also adds a sentence-initial and sentence-final token.
        Output is provided as a list of words.        
        """
        sentlist = ["<s>"]
        for word in sentence:
            if word != "":
                mooiwoord = re.search(r"\w+(\W+\w+)*", word)		#eliminate punctuation
                if mooiwoord:
                    sentlist.append(mooiwoord.group(0).lower())		#convert to lowercase and add to sentlist
        sentlist.append("</s>")
        return sentlist

    def p_raw (self, word1, word2):
        """
        Takes to strings as input and computes the probability (without
        smoothing) that the second words follows the first in the
        corpus (P(w2|w1).
        If either words does not occur in the corpus, the method will return 0.
        Output is a number between 0.0 and 1.0
        """
        if word1 in self.unigrams:
            if word2 not in self.bigramscount[word1]:
                return 0
            else:
                p = float(self.bigramscount[word1][word2]) / self.unigramcount[word1]		#p = bigram frequency / unigram frequency
                return p
        else:
            return 0

    def p_smooth (self, word1, word2):
        """
        Similar to p_raw: takes two strings as input and computes the
        probability that the second follows the first in the corpus (P(w2|w1)),
        but with Laplace smoothing applied.
        If either word does not occur in the corpus, the method will return 0.
        Output is a number between 0.0 and 1.0
        """
        if word1 in self.unigrams:
            newunigram = self.typescount + self.unigramcount[word1]			#unigram frequency after smoothing is raw unigram frequency + V
            if word2 in self.bigramscount[word1]:
                newbigram = self.bigramscount[word1][word2] + 1				#bigram frequency after smoothing is raw bigram frequency + 1
            elif word2 in self.unigrams:
                newbigram = 1
            else:
                newbigram = 0
            p = float(newbigram) / newunigram		#again p = bigram frequency / unigram frequency
            return p
        else:
            return 0

    def successors(self, w):
        """
        Takes a string as input and returns all words that follow it in the
        corpus with their raw probabilities.
        Output is presented as a list of tuples, each consisting of the word
        and the probability.
        """
        pairlist = []
        for w_i in self.bigramscount[w]:
            pairlist.append((w_i, self.p_raw(w, w_i)))
        return pairlist

    def perplexity (self, sent):
        """
        Takes a tokenised sentence as input (a list of words, may contain
        punctuation and capitalisation).
        Calculates the perplexity of the sentence based on the corpus. Output
        is return as a float value.
        """
        product = 1
        thissent = self._makenice(sent)
        for y in range(1, len(thissent)):
            word = thissent[y]
            if word not in self.bigramscount:
                return 0
            p = 1 / self.p_smooth(word, thissent[y-1])
            product = product*p
        n = len(thissent)
        return product ** (1/n)
