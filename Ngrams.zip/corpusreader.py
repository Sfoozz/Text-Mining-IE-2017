import os, re
class CorpusReader:
    '''
    The CorpusReader takes as input any textfile and returns a list of
    tokenized words.
    
    By Davy Baardink, Luka van der Plas & Tessa Vermeir
    '''
    def __init__(self, directory):
        """
        When the class CorpusReader is called, the initiator first checks if
        the directory exists (if it does not, it raises an error message). Then
        it defines a list 'textlist'.
        In the for-loop that follows, a connection is made with the text and
        its contents are appended to textlist. Finally, the lines in textlist
        are joined into a new variable called 'text'. The intiator takes 'self'
        as an argument, because it is not a local variable; it also takes
        directory as an argument, because it needs to work on directory paths.
        """
        if os.path.isdir(directory):
            self.path = directory
        else:
            raise ValueError(directory + " does not exist or is not a directory")
        textlist = []
        for filename in os.listdir(self.path):
            if filename.endswith(".txt"):
                connection = open(directory+"/"+filename, "r")
                text = connection.read()
                connection.close()
                textlist.append(text)
        self.text = "\n".join(textlist)

    def sents(self):
        """
        The definition 'sents' splits the content of 'text' into lists of
        sentences, using the symbol # to find the boundaries of the sentences.
        This also takes 'self' as an argument, again because it is not supposed
        to be a local variable. Then the variable 'list_of_wordlists' is
        created; with the for-loop that follows, the sentences generated in
        'filesentences' are again split, this time into words and saved in the
        variable 'words', and appended to list_of_wordlists. The result, a list
        containing lists of words (i.e. the words of the original sentences
        from the source text), is then returned. This is the final output of
        CorpusReader that can be used as input for other modules.
        """
        filesentences = self.text.split('#')
        list_of_wordlists = []
        for sentence in filesentences:
            words = re.split(r"\s", sentence)
            list_of_wordlists.append(words)
        return list_of_wordlists
